<footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>All rights reserved</b>
    </div>
    <strong>Copyright &copy; <?php echo date('Y'); ?> <span style="color: blue;">Prime Assets</span></strong>
</footer>