<footer class="footer text-center text-sm-left">
    &copy; <?php echo $year." ".$settings->siteTitle; ?> <span class="d-none d-sm-inline-block float-right">All Rights Reserved.</span>
</footer>