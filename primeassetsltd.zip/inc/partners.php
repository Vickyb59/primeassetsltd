
<section id="our-partners" class="padding bgsite">
    <div class="container">
        <div class="row">
            <h2 class="d-none">Partners</h2>
            <div class="col-md-12 col-sm-12">
                <div id="partners-slider" class="owl-carousel">
                    <div class="item">
                        <div class="logo-item"> <img alt="" src="images/logo-1.png"></div>
                    </div>
                    <div class="item">
                        <div class="logo-item"><img alt="" src="images/logo-2.png"></div>
                    </div>
                    <div class="item">
                        <div class="logo-item"><img alt="" src="images/logo-3.png"></div>
                    </div>
                    <div class="item">
                        <div class="logo-item"><img alt="" src="images/logo-4.png"></div>
                    </div>
                    <div class="item">
                        <div class="logo-item"><img alt="" src="images/logo-5.png"></div>
                    </div>
                    <div class="item">
                        <div class="logo-item"><img alt="" src="images/logo-6.png"></div>
                    </div>
                    <div class="item">
                        <div class="logo-item"><img alt="" src="images/logo-7.png"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>