
						<h2>Welcome to Manage Investment.</h2>
						<p>Your Account:</p>
						<p>Email: ".$email."</p>
						<p>Password: ".$_POST['password']."</p>
						<p>Please click the link below to activate your account.</p>
						<a href='https://manage-investment.com/activate.php?code=".$code."&user=".$userid."'>Activate Account</a>