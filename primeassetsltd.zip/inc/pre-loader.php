<div class="preloader">
    <div class="preloader-wrapper">
        <div></div>
        <div></div>
        <div></div>
        <div></div>
    </div>
</div>
<a href="#0" class="scrollToTop"><i class="fas fa-angle-up"></i></a>
<div class="overlay"></div>